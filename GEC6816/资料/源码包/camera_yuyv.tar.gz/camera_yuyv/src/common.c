#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <sys/stat.h>

unsigned char bcc_check(unsigned char *buf, int n)
{
    int i;
    unsigned char bcc=0;
	
    for(i = 0; i < n; i++)
    {
        bcc ^= *(buf+i);
    }
	
    return (~bcc);
}
