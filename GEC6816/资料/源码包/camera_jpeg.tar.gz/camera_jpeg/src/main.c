#include <stdio.h>
#include "api_v4l2.h"
#include "yuyv.h"
#include "lcdjpg.h"

int main(void)
{
	FrameBuffer freambuf;
	//1、初始化摄像头
	linux_v4l2_device_init("/dev/video0");
	//2、启动摄像头捕捉
	linux_v4l2_start_capturing();
	
	//3、获取摄像头数据
	while(1)
	{
		linux_v4l2_get_fream(&freambuf);
		lcd_draw_jpg(0,0,NULL,freambuf.buf,freambuf.length,0);
		
	}
	
	linux_v4l2_stop_capturing();
	linux_v4l2_device_uinit();
	
	return 0;
}
